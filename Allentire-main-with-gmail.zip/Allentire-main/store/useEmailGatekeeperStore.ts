import { create } from 'zustand';

export interface Email {
  id: string;
  threadId: string;
  subject: string;
  from: string;
  to: string;
  snippet: string;
  body: string;
  date: Date;
  isImportant?: boolean;
  importance_score?: number;
  category?: 'urgent' | 'important' | 'normal' | 'spam';
  reason?: string;
  labels: string[];
  hasAttachments: boolean;
  isRead?: boolean;
}

interface EmailStats {
  total: number;
  important: number;
  urgent: number;
  normal: number;
  spam: number;
  unread: number;
}

interface EmailGatekeeperState {
  emails: Email[];
  filteredEmails: Email[];
  isLoading: boolean;
  isConnected: boolean;
  lastSync: Date | null;
  stats: EmailStats;
  filter: 'all' | 'important' | 'urgent' | 'normal' | 'spam';
  searchQuery: string;
  llmApiKey: string;
  
  // Actions
  setEmails: (emails: Email[]) => void;
  setLoading: (loading: boolean) => void;
  setConnected: (connected: boolean) => void;
  setFilter: (filter: 'all' | 'important' | 'urgent' | 'normal' | 'spam') => void;
  setSearchQuery: (query: string) => void;
  setLLMApiKey: (apiKey: string) => void;
  updateEmail: (id: string, updates: Partial<Email>) => void;
  removeEmail: (id: string) => void;
  refreshEmails: () => Promise<void>;
  connectGmail: () => Promise<void>;
  disconnectGmail: () => void;
  classifyEmails: () => Promise<void>;
}

export const useEmailGatekeeperStore = create<EmailGatekeeperState>((set, get) => ({
  emails: [],
  filteredEmails: [],
  isLoading: false,
  isConnected: false,
  lastSync: null,
  stats: {
    total: 0,
    important: 0,
    urgent: 0,
    normal: 0,
    spam: 0,
    unread: 0,
  },
  filter: 'all',
  searchQuery: '',
  llmApiKey: '',

  setEmails: (emails) => {
    const stats = calculateStats(emails);
    const filtered = filterEmails(emails, get().filter, get().searchQuery);
    
    set({ 
      emails, 
      filteredEmails: filtered,
      stats,
      lastSync: new Date(),
    });
  },

  setLoading: (isLoading) => set({ isLoading }),

  setConnected: (isConnected) => set({ isConnected }),

  setFilter: (filter) => {
    const { emails, searchQuery } = get();
    const filtered = filterEmails(emails, filter, searchQuery);
    set({ filter, filteredEmails: filtered });
  },

  setSearchQuery: (searchQuery) => {
    const { emails, filter } = get();
    const filtered = filterEmails(emails, filter, searchQuery);
    set({ searchQuery, filteredEmails: filtered });
  },

  setLLMApiKey: (llmApiKey) => {
    set({ llmApiKey });
    // Store in electron-store
    if (window.electron) {
      window.electron.invoke('store-llm-api-key', llmApiKey);
    }
  },

  updateEmail: (id, updates) => {
    const emails = get().emails.map(email => 
      email.id === id ? { ...email, ...updates } : email
    );
    get().setEmails(emails);
  },

  removeEmail: (id) => {
    const emails = get().emails.filter(email => email.id !== id);
    get().setEmails(emails);
  },

  refreshEmails: async () => {
    if (!get().isConnected) {
      console.warn('Not connected to Gmail');
      return;
    }

    set({ isLoading: true });
    
    try {
      // Call electron IPC to fetch emails
      const emails = await window.electron.invoke('fetch-emails', { maxResults: 50 });
      get().setEmails(emails);
      
      // Auto-classify if LLM key is available
      if (get().llmApiKey) {
        await get().classifyEmails();
      }
    } catch (error) {
      console.error('Error refreshing emails:', error);
    } finally {
      set({ isLoading: false });
    }
  },

  connectGmail: async () => {
    set({ isLoading: true });
    
    try {
      const success = await window.electron.invoke('gmail-connect');
      if (success) {
        set({ isConnected: true });
        await get().refreshEmails();
      }
    } catch (error) {
      console.error('Error connecting to Gmail:', error);
    } finally {
      set({ isLoading: false });
    }
  },

  disconnectGmail: () => {
    window.electron.invoke('gmail-disconnect');
    set({ 
      isConnected: false, 
      emails: [], 
      filteredEmails: [],
      lastSync: null,
    });
  },

  classifyEmails: async () => {
    const { emails, llmApiKey } = get();
    
    if (!llmApiKey) {
      console.warn('No LLM API key configured');
      return;
    }

    if (emails.length === 0) {
      return;
    }

    set({ isLoading: true });
    
    try {
      // Call electron IPC to classify emails
      const classifications = await window.electron.invoke('classify-emails', {
        emails,
        apiKey: llmApiKey,
      });

      // Update emails with classifications
      const updatedEmails = emails.map(email => {
        const classification = classifications.find((c: any) => c.id === email.id);
        if (classification) {
          return {
            ...email,
            isImportant: classification.isImportant,
            importance_score: classification.importance_score,
            category: classification.category,
            reason: classification.reason,
          };
        }
        return email;
      });

      get().setEmails(updatedEmails);
    } catch (error) {
      console.error('Error classifying emails:', error);
    } finally {
      set({ isLoading: false });
    }
  },
}));

// Helper functions
function calculateStats(emails: Email[]): EmailStats {
  return {
    total: emails.length,
    important: emails.filter(e => e.category === 'important').length,
    urgent: emails.filter(e => e.category === 'urgent').length,
    normal: emails.filter(e => e.category === 'normal').length,
    spam: emails.filter(e => e.category === 'spam').length,
    unread: emails.filter(e => !e.isRead).length,
  };
}

function filterEmails(
  emails: Email[], 
  filter: 'all' | 'important' | 'urgent' | 'normal' | 'spam',
  searchQuery: string
): Email[] {
  let filtered = emails;

  // Apply category filter
  if (filter !== 'all') {
    filtered = filtered.filter(email => email.category === filter);
  }

  // Apply search filter
  if (searchQuery) {
    const query = searchQuery.toLowerCase();
    filtered = filtered.filter(email => 
      email.subject.toLowerCase().includes(query) ||
      email.from.toLowerCase().includes(query) ||
      email.snippet.toLowerCase().includes(query)
    );
  }

  return filtered;
}

// Extend Window interface for TypeScript
declare global {
  interface Window {
    electron: {
      invoke: (channel: string, ...args: any[]) => Promise<any>;
      on: (channel: string, callback: (...args: any[]) => void) => void;
      removeListener: (channel: string, callback: (...args: any[]) => void) => void;
    };
  }
}
