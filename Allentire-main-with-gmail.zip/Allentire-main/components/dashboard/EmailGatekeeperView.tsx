import React, { useState, useEffect } from 'react';
import {
  Mail,
  ArrowLeft,
  RefreshCw,
  Settings,
  Search,
  Filter,
  Trash2,
  Archive,
  ExternalLink,
  AlertCircle,
  CheckCircle,
  Clock,
  Sparkles,
  X,
} from 'lucide-react';
import { useEmailGatekeeperStore, Email } from '../../store/useEmailGatekeeperStore';

export const EmailGatekeeperView: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const {
    filteredEmails,
    stats,
    isLoading,
    isConnected,
    filter,
    searchQuery,
    llmApiKey,
    setFilter,
    setSearchQuery,
    setLLMApiKey,
    refreshEmails,
    connectGmail,
    disconnectGmail,
    classifyEmails,
    updateEmail,
    removeEmail,
  } = useEmailGatekeeperStore();

  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [apiKeyInput, setApiKeyInput] = useState(llmApiKey);

  useEffect(() => {
    if (isConnected && filteredEmails.length === 0) {
      refreshEmails();
    }
  }, [isConnected]);

  const handleSaveApiKey = () => {
    setLLMApiKey(apiKeyInput);
    setShowSettings(false);
  };

  const getCategoryColor = (category?: string) => {
    switch (category) {
      case 'urgent': return 'text-red-400 bg-red-500/10 border-red-500/20';
      case 'important': return 'text-blue-400 bg-blue-500/10 border-blue-500/20';
      case 'normal': return 'text-gray-400 bg-gray-500/10 border-gray-500/20';
      case 'spam': return 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20';
      default: return 'text-gray-400 bg-gray-500/10 border-gray-500/20';
    }
  };

  const getCategoryIcon = (category?: string) => {
    switch (category) {
      case 'urgent': return <AlertCircle size={12} />;
      case 'important': return <Mail size={12} />;
      case 'normal': return <CheckCircle size={12} />;
      case 'spam': return <Trash2 size={12} />;
      default: return <Mail size={12} />;
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-[#262626]">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="p-2 hover:bg-[#262626] rounded-lg transition-colors"
          >
            <ArrowLeft size={20} className="text-gray-400" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-white flex items-center gap-2">
              <Mail size={24} className="text-blue-500" />
              Email Gatekeeper
              <Sparkles size={16} className="text-purple-400" />
            </h1>
            <p className="text-xs text-gray-500">AI-powered email filtering</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {isConnected && (
            <>
              <button
                onClick={() => {
                  refreshEmails();
                  if (llmApiKey) classifyEmails();
                }}
                disabled={isLoading}
                className="flex items-center gap-2 px-3 py-2 bg-[#1a1a1a] hover:bg-[#262626] border border-[#333] rounded-lg text-sm text-gray-300 transition-colors disabled:opacity-50"
              >
                <RefreshCw size={16} className={isLoading ? 'animate-spin' : ''} />
                {isLoading ? 'Analyzing...' : 'Refresh & Classify'}
              </button>
              <button
                onClick={() => setShowSettings(!showSettings)}
                className="p-2 bg-[#1a1a1a] hover:bg-[#262626] border border-[#333] rounded-lg transition-colors"
              >
                <Settings size={20} className="text-gray-400" />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <div className="px-6 py-4 bg-[#161616] border-b border-[#262626]">
          <div className="max-w-2xl">
            <h3 className="text-sm font-bold text-white mb-3">LLM API Configuration</h3>
            <div className="flex gap-2">
              <input
                type="password"
                value={apiKeyInput}
                onChange={(e) => setApiKeyInput(e.target.value)}
                placeholder="Enter your OpenAI API key"
                className="flex-1 px-3 py-2 bg-[#0a0a0a] border border-[#333] rounded-lg text-sm text-white placeholder:text-gray-600 focus:outline-none focus:border-blue-500"
              />
              <button
                onClick={handleSaveApiKey}
                className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg text-sm font-medium transition-colors"
              >
                Save
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              Your API key is stored locally and used to classify emails with AI
            </p>
            
            {isConnected && (
              <div className="mt-4 pt-4 border-t border-[#262626]">
                <button
                  onClick={disconnectGmail}
                  className="text-sm text-red-400 hover:text-red-300 transition-colors"
                >
                  Disconnect Gmail
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {!isConnected ? (
        // Connection Screen
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center max-w-md px-6">
            <div className="w-20 h-20 rounded-full bg-blue-500/10 flex items-center justify-center mx-auto mb-4">
              <Mail size={40} className="text-blue-500" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Connect Your Gmail</h2>
            <p className="text-gray-400 mb-6">
              Let AI filter your emails and show only what's important. Spam and promotional emails will be automatically filtered out.
            </p>
            <button
              onClick={connectGmail}
              disabled={isLoading}
              className="px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-medium transition-colors disabled:opacity-50"
            >
              {isLoading ? 'Connecting...' : 'Connect Gmail Account'}
            </button>
            
            {!llmApiKey && (
              <div className="mt-6 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                <p className="text-xs text-yellow-400 flex items-center gap-2 justify-center">
                  <AlertCircle size={14} />
                  Don't forget to configure your LLM API key in settings
                </p>
              </div>
            )}
          </div>
        </div>
      ) : (
        // Main Email View
        <div className="flex-1 flex overflow-hidden">
          {/* Sidebar - Email List */}
          <div className="w-96 border-r border-[#262626] flex flex-col">
            {/* Search & Filter */}
            <div className="p-4 border-b border-[#262626]">
              <div className="relative mb-3">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search emails..."
                  className="w-full pl-9 pr-3 py-2 bg-[#1a1a1a] border border-[#333] rounded-lg text-sm text-white placeholder:text-gray-600 focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Filter Tabs */}
              <div className="flex gap-1">
                {(['all', 'urgent', 'important', 'normal', 'spam'] as const).map((f) => (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`flex-1 px-2 py-1.5 text-xs font-medium rounded transition-colors ${
                      filter === f
                        ? 'bg-blue-500 text-white'
                        : 'bg-[#1a1a1a] text-gray-400 hover:bg-[#262626]'
                    }`}
                  >
                    {f === 'all' ? `All (${stats.total})` : 
                     f === 'urgent' ? `${stats.urgent}` :
                     f === 'important' ? `${stats.important}` :
                     f === 'normal' ? `${stats.normal}` :
                     `${stats.spam}`}
                  </button>
                ))}
              </div>
            </div>

            {/* Email List */}
            <div className="flex-1 overflow-y-auto">
              {filteredEmails.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center p-6">
                  <CheckCircle size={40} className="text-gray-600 mb-2" />
                  <p className="text-gray-500 text-sm">No emails in this category</p>
                </div>
              ) : (
                filteredEmails.map((email) => (
                  <div
                    key={email.id}
                    onClick={() => setSelectedEmail(email)}
                    className={`p-4 border-b border-[#1a1a1a] cursor-pointer transition-colors hover:bg-[#161616] ${
                      selectedEmail?.id === email.id ? 'bg-[#161616] border-l-2 border-l-blue-500' : ''
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        <span className="text-sm font-medium text-white truncate">
                          {email.from.split('<')[0].trim() || email.from}
                        </span>
                        {email.category && (
                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider border ${getCategoryColor(email.category)} flex items-center gap-1 flex-shrink-0`}>
                            {getCategoryIcon(email.category)}
                            {email.category}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-gray-600 flex-shrink-0">
                        {new Date(email.date).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="text-sm font-medium text-gray-300 mb-1 truncate">
                      {email.subject}
                    </div>
                    <div className="text-xs text-gray-500 line-clamp-2">
                      {email.snippet}
                    </div>
                    {email.reason && (
                      <div className="mt-2 text-[10px] text-purple-400 italic">
                        💡 {email.reason}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Email Detail View */}
          <div className="flex-1 flex flex-col bg-[#0a0a0a]">
            {selectedEmail ? (
              <>
                <div className="p-6 border-b border-[#262626]">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h2 className="text-xl font-bold text-white mb-2">
                        {selectedEmail.subject}
                      </h2>
                      <div className="flex items-center gap-3 text-sm text-gray-400">
                        <span>From: {selectedEmail.from}</span>
                        <span>•</span>
                        <span>{new Date(selectedEmail.date).toLocaleString()}</span>
                      </div>
                    </div>
                    {selectedEmail.category && (
                      <span className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider border ${getCategoryColor(selectedEmail.category)} flex items-center gap-2`}>
                        {getCategoryIcon(selectedEmail.category)}
                        {selectedEmail.category}
                      </span>
                    )}
                  </div>

                  {selectedEmail.reason && (
                    <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-lg mb-4">
                      <div className="flex items-start gap-2">
                        <Sparkles size={14} className="text-purple-400 mt-0.5 flex-shrink-0" />
                        <div>
                          <div className="text-xs font-bold text-purple-400 mb-1">AI Analysis</div>
                          <div className="text-xs text-gray-300">{selectedEmail.reason}</div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2">
                    <button className="flex items-center gap-2 px-3 py-2 bg-[#1a1a1a] hover:bg-[#262626] border border-[#333] rounded-lg text-xs text-gray-300 transition-colors">
                      <Archive size={14} />
                      Archive
                    </button>
                    <button 
                      onClick={() => {
                        removeEmail(selectedEmail.id);
                        setSelectedEmail(null);
                      }}
                      className="flex items-center gap-2 px-3 py-2 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 rounded-lg text-xs text-red-400 transition-colors"
                    >
                      <Trash2 size={14} />
                      Delete
                    </button>
                    <button 
                      onClick={() => window.open(`https://mail.google.com/mail/u/0/#inbox/${selectedEmail.id}`, '_blank')}
                      className="flex items-center gap-2 px-3 py-2 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/20 rounded-lg text-xs text-blue-400 transition-colors ml-auto"
                    >
                      Open in Gmail
                      <ExternalLink size={14} />
                    </button>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto p-6">
                  <div className="prose prose-invert max-w-none">
                    <pre className="whitespace-pre-wrap text-sm text-gray-300 font-sans">
                      {selectedEmail.body}
                    </pre>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <Mail size={64} className="text-gray-700 mx-auto mb-4" />
                  <p className="text-gray-500">Select an email to view</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
