import React, { useEffect } from 'react';
import { Mail, RefreshCw, Settings, ChevronRight, AlertCircle, CheckCircle } from 'lucide-react';
import { Card } from '../ui/Card';
import { useEmailGatekeeperStore } from '../../store/useEmailGatekeeperStore';

interface EmailGatekeeperCardProps {
  onOpenFull?: () => void;
}

export const EmailGatekeeperCard: React.FC<EmailGatekeeperCardProps> = ({ onOpenFull }) => {
  const { 
    stats, 
    isLoading, 
    isConnected, 
    lastSync,
    refreshEmails,
  } = useEmailGatekeeperStore();

  // Auto-refresh on mount if connected
  useEffect(() => {
    if (isConnected) {
      refreshEmails();
    }
  }, [isConnected]);

  const urgentCount = stats.urgent;
  const importantCount = stats.important;

  return (
    <Card 
      title="Email Gatekeeper" 
      icon={Mail} 
      className="col-span-1 md:col-span-2 relative overflow-hidden"
    >
      {/* Loading Overlay */}
      {isLoading && (
        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm z-10 flex items-center justify-center">
          <div className="flex items-center gap-2 text-white">
            <RefreshCw className="animate-spin" size={20} />
            <span className="text-sm font-medium">Analyzing emails...</span>
          </div>
        </div>
      )}

      {!isConnected ? (
        // Not connected state
        <div className="flex flex-col items-center justify-center h-full py-4">
          <div className="w-16 h-16 rounded-full bg-blue-500/10 flex items-center justify-center mb-3">
            <Mail size={32} className="text-blue-500" />
          </div>
          <h3 className="text-lg font-bold text-white mb-1">Connect Your Gmail</h3>
          <p className="text-xs text-gray-500 text-center mb-4 max-w-xs">
            AI-powered email filtering to show only what matters
          </p>
          <button
            onClick={onOpenFull}
            className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg text-sm font-medium transition-colors"
          >
            Connect Gmail
          </button>
        </div>
      ) : stats.total === 0 ? (
        // Inbox Zero state
        <div className="flex flex-col items-center justify-center h-full py-2">
          <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center mb-2">
            <CheckCircle size={24} className="text-green-500 drop-shadow-[0_0_10px_rgba(34,197,94,0.5)]" />
          </div>
          <h2 className="text-lg font-bold text-white mb-0.5">Inbox Zero</h2>
          <p className="text-xs text-gray-500">You're all caught up! 🎉</p>
          {lastSync && (
            <p className="text-[10px] text-gray-600 mt-2">
              Last checked: {lastSync.toLocaleTimeString()}
            </p>
          )}
        </div>
      ) : (
        // Email summary state
        <div className="flex flex-col h-full">
          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-3 mb-3">
            {/* Urgent Emails */}
            {urgentCount > 0 && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 hover:bg-red-500/20 transition-colors cursor-pointer">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-bold text-red-400 uppercase tracking-wider">
                    Urgent
                  </span>
                  <AlertCircle size={14} className="text-red-500" />
                </div>
                <div className="text-2xl font-bold text-white">{urgentCount}</div>
              </div>
            )}

            {/* Important Emails */}
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3 hover:bg-blue-500/20 transition-colors cursor-pointer">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider">
                  Important
                </span>
                <Mail size={14} className="text-blue-500" />
              </div>
              <div className="text-2xl font-bold text-white">{importantCount}</div>
            </div>

            {/* Total Filtered */}
            <div className="bg-gray-500/10 border border-gray-500/20 rounded-lg p-3 col-span-2">
              <div className="flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">
                    Total Scanned
                  </span>
                  <div className="text-xl font-bold text-white">{stats.total} emails</div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="text-[9px] text-gray-500">
                    {stats.spam} spam filtered
                  </span>
                  {lastSync && (
                    <span className="text-[9px] text-gray-600">
                      {lastSync.toLocaleTimeString()}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 mt-auto">
            <button
              onClick={refreshEmails}
              disabled={isLoading}
              className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-[#1a1a1a] hover:bg-[#262626] border border-[#333] rounded-lg text-xs font-medium text-gray-300 transition-colors disabled:opacity-50"
            >
              <RefreshCw size={12} className={isLoading ? 'animate-spin' : ''} />
              Refresh
            </button>
            <button
              onClick={onOpenFull}
              className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/20 rounded-lg text-xs font-bold text-blue-400 transition-colors"
            >
              View All
              <ChevronRight size={12} />
            </button>
          </div>
        </div>
      )}
    </Card>
  );
};
