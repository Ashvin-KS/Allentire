import { Email, EmailClassification } from './GmailService';

export interface LLMConfig {
  apiKey: string;
  model?: string;
  endpoint?: string;
}

export class EmailClassifierService {
  private apiKey: string;
  private model: string;
  private endpoint: string;

  constructor(config: LLMConfig) {
    this.apiKey = config.apiKey;
    this.model = config.model || 'gpt-4o-mini'; // Default to GPT-4 mini for cost efficiency
    this.endpoint = config.endpoint || 'https://api.openai.com/v1/chat/completions';
  }

  /**
   * Classify a single email using LLM
   */
  async classifyEmail(email: Email): Promise<EmailClassification> {
    const prompt = this.buildClassificationPrompt(email);

    try {
      const response = await fetch(this.endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify({
          model: this.model,
          messages: [
            {
              role: 'system',
              content: `You are an intelligent email classifier. Analyze emails and determine if they are important, urgent, normal, or spam. 
              
              Classification criteria:
              - URGENT: Time-sensitive actions required, critical deadlines, emergencies
              - IMPORTANT: Work-related, from key contacts, requires attention but not immediate
              - NORMAL: General correspondence, newsletters you're interested in, social updates
              - SPAM: Promotional emails, unwanted marketing, suspicious content
              
              Respond ONLY with a valid JSON object in this exact format:
              {
                "isImportant": true/false,
                "importance_score": 0-100,
                "reason": "brief explanation",
                "category": "urgent/important/normal/spam"
              }`
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.3,
          max_tokens: 200,
        }),
      });

      if (!response.ok) {
        throw new Error(`LLM API error: ${response.statusText}`);
      }

      const data = await response.json();
      const content = data.choices[0].message.content;
      
      // Parse the JSON response
      const result = JSON.parse(content);

      return {
        id: email.id,
        isImportant: result.isImportant,
        importance_score: result.importance_score,
        reason: result.reason,
        category: result.category,
      };
    } catch (error) {
      console.error('Error classifying email:', error);
      // Return a default classification on error
      return {
        id: email.id,
        isImportant: false,
        importance_score: 50,
        reason: 'Classification failed',
        category: 'normal',
      };
    }
  }

  /**
   * Classify multiple emails in batch
   */
  async classifyEmails(emails: Email[]): Promise<EmailClassification[]> {
    // Process in batches to avoid rate limits
    const batchSize = 5;
    const results: EmailClassification[] = [];

    for (let i = 0; i < emails.length; i += batchSize) {
      const batch = emails.slice(i, i + batchSize);
      const batchPromises = batch.map(email => this.classifyEmail(email));
      const batchResults = await Promise.all(batchPromises);
      results.push(...batchResults);

      // Add small delay between batches to respect rate limits
      if (i + batchSize < emails.length) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }

    return results;
  }

  /**
   * Build the classification prompt for an email
   */
  private buildClassificationPrompt(email: Email): string {
    return `Analyze this email and classify its importance:

FROM: ${email.from}
TO: ${email.to}
SUBJECT: ${email.subject}
DATE: ${email.date.toISOString()}
HAS_ATTACHMENTS: ${email.hasAttachments}

PREVIEW:
${email.snippet}

BODY (first 1000 chars):
${email.body.substring(0, 1000)}

Classify this email and explain your reasoning.`;
  }

  /**
   * Generate a summary of important emails
   */
  async generateEmailDigest(emails: Email[], classifications: EmailClassification[]): Promise<string> {
    const importantEmails = emails.filter((email, index) => 
      classifications[index].isImportant
    );

    if (importantEmails.length === 0) {
      return "You have no important emails at this time. Your inbox is clear! 🎉";
    }

    const emailSummaries = importantEmails.slice(0, 10).map((email, index) => {
      const classification = classifications.find(c => c.id === email.id);
      return `${index + 1}. [${classification?.category.toUpperCase()}] ${email.subject}
   From: ${email.from}
   ${classification?.reason}`;
    }).join('\n\n');

    const prompt = `Create a brief, friendly digest of these important emails. Keep it concise and actionable:

${emailSummaries}

Provide a 2-3 sentence summary highlighting the most urgent items.`;

    try {
      const response = await fetch(this.endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify({
          model: this.model,
          messages: [
            {
              role: 'system',
              content: 'You are a helpful email assistant. Create brief, actionable email digests.'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.7,
          max_tokens: 300,
        }),
      });

      const data = await response.json();
      return data.choices[0].message.content;
    } catch (error) {
      console.error('Error generating digest:', error);
      return `You have ${importantEmails.length} important email(s) requiring attention.`;
    }
  }

  /**
   * Update API configuration
   */
  updateConfig(config: Partial<LLMConfig>) {
    if (config.apiKey) this.apiKey = config.apiKey;
    if (config.model) this.model = config.model;
    if (config.endpoint) this.endpoint = config.endpoint;
  }
}
