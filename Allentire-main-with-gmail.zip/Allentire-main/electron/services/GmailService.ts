import { google } from 'googleapis';
import { OAuth2Client } from 'google-auth-library';

export interface Email {
  id: string;
  threadId: string;
  subject: string;
  from: string;
  to: string;
  snippet: string;
  body: string;
  date: Date;
  isImportant?: boolean;
  importance_score?: number;
  labels: string[];
  hasAttachments: boolean;
}

export interface EmailClassification {
  id: string;
  isImportant: boolean;
  importance_score: number;
  reason: string;
  category: 'urgent' | 'important' | 'normal' | 'spam';
}

export class GmailService {
  private gmail: any;

  constructor(private auth: OAuth2Client) {
    this.gmail = google.gmail({ version: 'v1', auth: this.auth });
  }

  /**
   * Fetch recent emails from Gmail
   * @param maxResults Maximum number of emails to fetch
   * @param query Gmail search query (e.g., 'is:unread', 'newer_than:7d')
   */
  async fetchEmails(maxResults: number = 50, query: string = 'newer_than:7d'): Promise<Email[]> {
    try {
      // Get list of message IDs
      const response = await this.gmail.users.messages.list({
        userId: 'me',
        maxResults,
        q: query,
      });

      const messages = response.data.messages || [];
      
      if (messages.length === 0) {
        return [];
      }

      // Fetch full details for each message
      const emailPromises = messages.map((message: any) => 
        this.getEmailDetails(message.id)
      );

      const emails = await Promise.all(emailPromises);
      return emails.filter(email => email !== null) as Email[];
    } catch (error) {
      console.error('Error fetching emails:', error);
      throw error;
    }
  }

  /**
   * Get detailed information for a single email
   */
  private async getEmailDetails(messageId: string): Promise<Email | null> {
    try {
      const response = await this.gmail.users.messages.get({
        userId: 'me',
        id: messageId,
        format: 'full',
      });

      const message = response.data;
      const headers = message.payload.headers;

      // Extract headers
      const getHeader = (name: string) => {
        const header = headers.find((h: any) => h.name.toLowerCase() === name.toLowerCase());
        return header ? header.value : '';
      };

      const subject = getHeader('Subject');
      const from = getHeader('From');
      const to = getHeader('To');
      const dateStr = getHeader('Date');

      // Extract body
      let body = '';
      if (message.payload.body.data) {
        body = Buffer.from(message.payload.body.data, 'base64').toString('utf-8');
      } else if (message.payload.parts) {
        // Handle multipart messages
        for (const part of message.payload.parts) {
          if (part.mimeType === 'text/plain' && part.body.data) {
            body = Buffer.from(part.body.data, 'base64').toString('utf-8');
            break;
          } else if (part.mimeType === 'text/html' && part.body.data && !body) {
            body = Buffer.from(part.body.data, 'base64').toString('utf-8');
          }
        }
      }

      // Check for attachments
      const hasAttachments = message.payload.parts?.some((part: any) => 
        part.filename && part.filename.length > 0
      ) || false;

      return {
        id: message.id,
        threadId: message.threadId,
        subject,
        from,
        to,
        snippet: message.snippet || '',
        body: body.substring(0, 5000), // Limit body size
        date: new Date(dateStr),
        labels: message.labelIds || [],
        hasAttachments,
      };
    } catch (error) {
      console.error(`Error fetching email ${messageId}:`, error);
      return null;
    }
  }

  /**
   * Mark email as read
   */
  async markAsRead(messageId: string): Promise<void> {
    try {
      await this.gmail.users.messages.modify({
        userId: 'me',
        id: messageId,
        requestBody: {
          removeLabelIds: ['UNREAD'],
        },
      });
    } catch (error) {
      console.error(`Error marking email ${messageId} as read:`, error);
      throw error;
    }
  }

  /**
   * Archive email (remove from inbox)
   */
  async archiveEmail(messageId: string): Promise<void> {
    try {
      await this.gmail.users.messages.modify({
        userId: 'me',
        id: messageId,
        requestBody: {
          removeLabelIds: ['INBOX'],
        },
      });
    } catch (error) {
      console.error(`Error archiving email ${messageId}:`, error);
      throw error;
    }
  }

  /**
   * Move email to trash
   */
  async trashEmail(messageId: string): Promise<void> {
    try {
      await this.gmail.users.messages.trash({
        userId: 'me',
        id: messageId,
      });
    } catch (error) {
      console.error(`Error trashing email ${messageId}:`, error);
      throw error;
    }
  }

  /**
   * Add label to email
   */
  async addLabel(messageId: string, labelId: string): Promise<void> {
    try {
      await this.gmail.users.messages.modify({
        userId: 'me',
        id: messageId,
        requestBody: {
          addLabelIds: [labelId],
        },
      });
    } catch (error) {
      console.error(`Error adding label to email ${messageId}:`, error);
      throw error;
    }
  }

  /**
   * Get user's Gmail labels
   */
  async getLabels(): Promise<any[]> {
    try {
      const response = await this.gmail.users.labels.list({
        userId: 'me',
      });
      return response.data.labels || [];
    } catch (error) {
      console.error('Error fetching labels:', error);
      throw error;
    }
  }
}
